<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from quiety.themetags.com/index-9.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jul 2022 12:03:38 GMT -->
<head>
    <!--required meta tags-->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--twitter og-->
    <meta name="twitter:site" content="@themetags">
    <meta name="twitter:creator" content="@themetags">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Quiety - Creative SAAS Technology & IT Solutions Bootstrap 5 HTML Template">
    <meta name="twitter:description" content="Quiety creative Saas, software technology, Saas agency & business Bootstrap 5 Html template. It is best and famous software company and Saas website template.">
    <meta name="twitter:image" content="#">

    <!--facebook og-->
    <meta property="og:url" content="#">
    <meta name="twitter:title" content="Quiety - Creative SAAS Technology & IT Solutions Bootstrap 5 HTML Template">
    <meta property="og:description" content="Quiety creative Saas, software technology, Saas agency & business Bootstrap 5 Html template. It is best and famous software company and Saas website template.">
    <meta property="og:image" content="#">
    <meta property="og:image:secure_url" content="#">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!--meta-->
    <meta name="description" content="Quiety creative Saas, software technology, Saas agency & business Bootstrap 5 Html template. It is best and famous software company and Saas website template.">
    <meta name="author" content="ThemeTags">

    <?php include("A2Rinclude/header_cdn.php");?>

</head>

<body>

    <!--preloader start-->
    <?php include("A2Rinclude/preloader.php");?>
    <!--preloader end-->
    <!--main content wrapper start-->
    <div class="main-wrapper">
        <!--header section start-->
        <!--header start-->
       <?php include("A2Rinclude/header.php");?>
        <!--header end-->
        <!--header section end-->

        <!--customers section start
        <section class="promo-section ptb-120 bg-light ">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-10 col-lg-6">
                        <div class="section-heading text-center" data-aos="fade-up">
                            <h2>A2R Store Themes</h2>
                            <p>Discover themes from our curated collection & start with the one perfect for your business.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-lg-4 mt-4 mt-lg-0 mt-md-0">
                        <div class="bg-dark p-5 text-center d-flex flex-column h-100 rounded-custom" data-aos="fade-up" data-aos-delay="100">
                            <div class="promo-card-info mb-4">
                                <h5 class="display-5 fw-bold mb-4"><i class="far fa-fingerprint text-warning me-2"></i> 
                                    Fully Responsive
                                </h5>
                                <p>Incredibly fast storefronts. Don't take our word for it, start selling online and see it for yourself! </p>
                            </div>
                            <div class="mt-auto">
                                <img src="assets/img/clients/client-logo-4.svg" width="120" alt="clients" class="img-fluid me-auto customer-logo">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-4 mt-lg-0 mt-md-0">
                        <div class="bg-dark p-5 text-center d-flex flex-column h-100 rounded-custom" data-aos="fade-up" data-aos-delay="150">
                            <div class="promo-card-info mb-4">
                                <h3 class="display-5 fw-bold mb-4"><i class="far fa-paper-plane text-warning me-2"></i> Highly Customizable
                                </h3>
                                <p>Customizing your theme according to your branding could not be as easy as it is on A2R Store.</p>
                            </div>
                            <div class="mt-auto">
                                <img src="assets/img/clients/client-logo-2.svg" width="120" alt="clients" class="img-fluid me-auto customer-logo">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-4 mt-lg-0">
                        <div class="bg-dark p-5 text-center d-flex flex-column h-100 rounded-custom" data-aos="fade-up" data-aos-delay="200">
                            <div class="promo-card-info mb-4">
                                <h3 class="display-5 fw-bold mb-4"><i class="far fa-chart-pie-alt text-warning me-2"></i>
                                    Quick checkouts</h3>
                                <p>Offer your customers a seamless shopping experience in addition to quick checkouts. </p>
                            </div>
                            <div class="mt-auto">
                                <img src="assets/img/clients/client-logo-3.svg" width="120" alt="clients" class="img-fluid me-auto customer-logo">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        customers section end-->


        
        <!-- portfolio start -->
        <section class="portfolio bg-light ptb-120">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-10">
                        <div class="section-heading text-center">
                            <h2><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2rstore.png" style="width:30%; height: auto;"> Themes</h2>
                            <p>
                                Discover themes from our curated collection & start with the one perfect for your business.
                            </p>
                        </div>
                    </div>
                </div>
                <!--<div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="tab-button mb-5">
                            <ul class="nav nav-pills d-flex justify-content-center" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-all-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab" aria-controls="pills-all" aria-selected="true">
                                        All
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-branding-tab" data-bs-toggle="pill" data-bs-target="#pills-branding" type="button" role="tab" aria-controls="pills-branding" aria-selected="false">
                                        Food & Drink
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-design-tab" data-bs-toggle="pill" data-bs-target="#pills-design" type="button" role="tab" aria-controls="pills-design" aria-selected="false">
                                        Health & Beauty
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-logo-tab" data-bs-toggle="pill" data-bs-target="#pills-logo" type="button" role="tab" aria-controls="pills-logo" aria-selected="false">
                                        Fashion & Clothing
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">
                                        Home & Garden
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">
                                        Furnitures & Manufacturing
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">
                                        Gift ,Toys & Games
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-web-tab" data-bs-toggle="pill" data-bs-target="#pills-web" type="button" role="tab" aria-controls="pills-web" aria-selected="false">
                                        Electronics
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tab-content" id="pills-tabContent">
                         All -->
                       <div class="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-1.jpg" alt="portfolio photo" class="img-fluid" /><br><br><p class="limit-2-line-text" >BLACK THEME</p>
                                             <div class="d-flex align-items-center pt-4">
                                        <div class="avatar">
                                            <!--<img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 20%">-->
                                        </div>
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name" style="padding: ;"><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 10%">Design By - Shalu Singh</h6>
                                            <span class="small fw-medium text-muted">April 24, 2021</span>
                                        </div>
                                    </div>
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="https://a2rstore.com/ecommerce/theme/software/v1/index.php?a2rTokenKey=A2REco22121063944c310bc9b" target="_blank" class="text-decoration-none text-white" style="background-color: blue; padding: 8px; border-radius:5px">Preview
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Black Theme</span>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-Screenshot_2023-04-03-13-06-37-818-edit_com.android.chrome.jpg" alt="portfolio photo" class="img-fluid" /><br><br><p class="limit-2-line-text" >WHITE THEME</p>
                                            <div class="d-flex align-items-center pt-4">
                                        <div class="avatar">
                                           <!-- <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width:20%">-->
                                        </div>
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name"><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 10%">Design By -  </h6>
                                            <span class="small fw-medium text-muted">April 24, 2021</span>
                                        </div>
                                    </div>
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="https://a2rstore.com/ecommerce/theme/jewellery/v2/index.php?a2rTokenKey=A2REco221124637f2a9c15ba2" class="text-decoration-none text-white" target="_blank" style="background-color: blue; padding: 8px; border-radius:5px">Preview
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>White Theme</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-Screenshot_2023-04-03-13-09-35-231-edit_com.android.chrome%20(1).jpg" alt="portfolio photo" class="img-fluid" /><br><br><p class="limit-2-line-text" >PINK THEME</p>
                                            <div class="d-flex align-items-center pt-4">
                                        <div class="avatar">
                                            <!--<img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width:20%">-->
                                        </div>
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name"><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 10%">Design By -  </h6>
                                            <span class="small fw-medium text-muted">April 24, 2021</span>
                                        </div>
                                    </div>
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="https://a2rstore.com/ecommerce/theme/automobile/redcolor/v3/index.php?a2rTokenKey=A2REco221208639184fd6f658&themeId=redTheme0156gg" target="_blank" class="text-decoration-none text-white" style="background-color: blue; padding: 8px; border-radius:5px">Preview
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Pink Theme</span>
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="blog-single.html">
                                    <h2 class="h5 article-title limit-2-line-text"></h2>
                                </a>
                                <p class="limit-2-line-text"></p>

                                <a href="javascript:;">
                                    <div class="d-flex align-items-center pt-4">
                                       <!-- <div class="avatar">
                                            <img src="assets/img/testimonial/6.jp" alt="avatar" width="40" class="img-fluid rounded-circle me-3">
                                        </div>-->
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name"></h6>
                                            <span class="small fw-medium text-muted"></span>
                                        </div>
                                    </div>
                                </a>

                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-Screenshot_2023-04-03-15-19-21-873-edit_com.android.chrome%20(1).jpg" alt="portfolio photo" class="img-fluid" /><br><br><p class="limit-2-line-text" >BLUE THEME</p>
                                             <div class="d-flex align-items-center pt-4">
                                        <div class="avatar">
                                            <!--<img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 20%">-->
                                        </div>
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name"><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 10%">Design By -  </h6>
                                            <span class="small fw-medium text-muted">April 24, 2021</span>
                                        </div>
                                    </div>
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="https://a2rstore.com/ecommerce/theme/restaurant/v2/index.php?a2rTokenKey=a2r002abhmeatndo&themeId=greenTheme01767" class="text-decoration-none text-white" target="blank"style="background-color: blue; padding: 8px; border-radius:5px">Preview
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Blue Theme</span>
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-Screenshot_2023-04-04-12-46-55-213-edit_com.android.chrome.jpg" class="img-fluid" /><br><br><p class="limit-2-line-text" >BLUE THEME</p>
                                            <div class="d-flex align-items-center pt-4">
                                        <div class="avatar">
                                            <!--<img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 20%">-->
                                        </div>
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name" style="padding: ;"><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 10%">Design By -  </h6>
                                            <span class="small fw-medium text-muted">April 24, 2021</span>
                                        </div>
                                    </div>
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="https://a2rstore.com/ecommerce/theme/restaurant/v2/index.php?a2rTokenKey=A2REco23033164266dd45ac4f&themeId=greenTheme01767" class="text-decoration-none text-white" target="_blank" style="background-color: blue; padding: 8px; border-radius:5px">Preview
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Blue Theme</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-Screenshot_2023-04-03-13-22-11-728-edit_com.android.chrome.jpg" alt="portfolio photo" class="img-fluid" /><br><br><p class="limit-2-line-text" >GREEN THEME</p>
                                            <div class="d-flex align-items-center pt-4">
                                        <div class="avatar">
                                            <!--<img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width:20%">-->
                                        </div>
                                        <div class="avatar-info">
                                            <h6 class="mb-0 avatar-name"><img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2r.png" alt="avatar" width="40" class="img-fluid rounded-circle me-3" style="width: 10%">Design By -  </h6>
                                            <span class="small fw-medium text-muted">April 24, 2021</span>
                                        </div>
                                    </div>
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="https://a2rstore.com/ecommerce/theme/automobile/redcolor/v3/index.php?a2rTokenKey=A2REco221206638ef4411af74&themeId=redTheme0156gg" class="text-decoration-none text-white" target="_blank" style="background-color: blue; padding: 8px; border-radius:5px">Preview
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Green Theme</span>
                                                    <span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div>

                        <!-- Branding -->
                      <!--  <div class="tab-pane fade" id="pills-branding" role="tabpanel" aria-labelledby="pills-branding-tab">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio2.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Leafery Branding
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio3.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Information Architencure
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio4.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Light
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Design</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Design -->
                        <!--<div class="tab-pane fade" id="pills-design" role="tabpanel" aria-labelledby="pills-design-tab">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio1.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Website Design Project</a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Design,</span>
                                                    <span>Web</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio5.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Information Architencure
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio6.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Branding & Corporate Identity
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Logo -->
                        <!--<div class="tab-pane fade" id="pills-logo" role="tabpanel" aria-labelledby="pills-logo-tab">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio1.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Website Design Project</a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Design,</span>
                                                    <span>Web</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio2.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Leafery Branding
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-Screenshot%202023-03-27%20210611.png" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Information Architencure
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Web -->
                        <!--<div class="tab-pane fade" id="pills-web" role="tabpanel" aria-labelledby="pills-web-tab">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio1.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Website Design Project</a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Design,</span>
                                                    <span>Web</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio5.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Information Architencure
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="single-portfolio-item mb-30">
                                        <div class="portfolio-item-img">
                                            <img src="assets/img/portfolio/portfolio2.jpg" alt="portfolio photo" class="img-fluid" />
                                            <div class="portfolio-info">
                                                <h5>
                                                    <a href="portfolio-single.html" class="text-decoration-none text-white">Leafery Branding
                                                    </a>
                                                </h5>
                                                <div class="categories">
                                                    <span>Branding,</span>
                                                    <span>Logo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </section>
        <!-- portfolio end -->

        <!--cat subscribe start-->
        <!--<section class="cta-subscribe bg-dark text-white ptb-120 position-relative overflow-hidden">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-10">
                        <div class="subscribe-info-wrap text-center position-relative z-2">
                            <div class="section-heading" data-aos="fade-up">
                                <h4 class="h5 text-warning">Let's Try! Get Free Support</h4>
                                <h2>Start Your 14-Day Free Trial</h2>
                                <p>We can help you to create your dream website for better business revenue.</p>
                            </div>
                            <div class="form-block-banner mw-60 m-auto mt-5" data-aos="fade-up" data-aos-delay="50">
                                <a href="contact-us.html" class="btn btn-primary">Contact with Us</a>
                                <a href="http://www.youtube.com/watch?v=hAP2QF--2Dg" class="text-decoration-none popup-youtube d-inline-flex align-items-center watch-now-btn ms-lg-3 ms-md-3 mt-3 mt-lg-0"> <i
                                      class="fas fa-play"></i> Watch Demo </a>
                            </div>
                            <ul class="nav justify-content-center subscribe-feature-list mt-4" data-aos="fade-up" data-aos-delay="100">
                                <li class="nav-item">
                                    <span><i class="far fa-check-circle text-primary me-2"></i>Free 14-day trial</span>
                                </li>
                                <li class="nav-item">
                                    <span><i class="far fa-check-circle text-primary me-2"></i>No credit card required</span>
                                </li>
                                <li class="nav-item">
                                    <span><i class="far fa-check-circle text-primary me-2"></i>Support 24/7</span>
                                </li>
                                <li class="nav-item">
                                    <span><i class="far fa-check-circle text-primary me-2"></i>Cancel anytime</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="bg-circle rounded-circle circle-shape-3 position-absolute bg-dark-light left-5"></div>
                <div class="bg-circle rounded-circle circle-shape-1 position-absolute bg-warning right-5"></div>
            </div>
        </section>-->
        <!--cat subscribe end-->
        <!--footer section start-->
        <!--footer section start-->
      <?php include("A2Rinclude/footer.php");?>
        <!--footer section end-->
        <!--footer section end-->
    </div>


    <!--build:js-->
    <?php include("A2Rinclude/footer_cdn.php");?>
    <!--endbuild-->
</body>
</html>
