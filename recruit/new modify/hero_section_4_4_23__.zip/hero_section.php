<section class="hero-section ptb-120" style="background: url('assets/img/shape/dot-dot-wave-shape.svg')no-repeat bottom center">
            <div class="container">
                <div class="row align-items-center justify-content-lg-between">
                    <div class="col-xl-5 col-lg-5">
                        <div class="hero-content-wrap text-center text-xl-start text-lg-start" data-aos="fade-right">
                            <h2 class="fw-bold display-5">The global commerce platform, built for Sell Product Online</h2>
                            <p class="lead">Wanna Technology that grows your business online ?<br>Build your buisness with <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-a2rstore.png" style="width:20%; height: auto;">.</p>
                            <div class="hero-subscribe-form-wrap pt-4 position-relative m-auto m-xl-0 d-none d-md-block d-lg-block d-xl-block">
                                
                                <ul class="nav subscribe-feature-list mt-3">
                                    <li class="nav-item">
                                        <span class="ms-0"><i class="far fa-check-circle text-primary me-2"></i>Free 7-day trial</span>
                                    </li>
                                    <li class="nav-item">
                                        <span><i
                                                class="far fa-check-circle text-primary me-2"></i>No credit card required</span>
                                    </li>
                                </ul>
                            </div>
                            <div class="action-btns mt-4 ps-3">
                        
                        <a href="https://a2rstore.com/ecommerce/register/register-user.php" class="btn btn-primary">Start 7 Day Free Trial</a>
                    </div>

                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6 mt-4 mt-xl-0">
                        <div class="hero-img-wrap position-relative" data-aos="fade-left">
                            <!--animated shape start-->
                            <ul class="position-absolute animate-element parallax-element shape-service hide-medium">
                                <li class="layer" data-depth="0.03">
                                    <img src="assets/img/color-shape/image-1.svg" alt="shape" class="img-fluid position-absolute color-shape-1">
                                </li>
                                <li class="layer" data-depth="0.02">
                                    <img src="assets/img/color-shape/feature-2.svg" alt="shape" class="img-fluid position-absolute color-shape-2 z-5">
                                </li>
                                <li class="layer" data-depth="0.03">
                                    <img src="assets/img/color-shape/feature-3.svg" alt="shape" class="img-fluid position-absolute color-shape-3">
                                </li>
                            </ul>
                            <!--animated shape end-->
                            <div class="hero-img-wrap position-relative">
                                <div class="hero-screen-wrap">
                                    <div class="phone-screen">
                                        <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-phone-screen1.png" alt="hero image" class="position-relative img-fluid">
                                    </div>
                                    <div class="mac-screen">
                                        <img src="https://oceonicitsolution.com/software/v1/task-management-software/v2/images/task_msg-mac-screen1.png" alt="hero image" class="position-relative img-fluid rounded-custom">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>